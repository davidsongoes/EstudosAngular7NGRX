export interface Client {
    id: number,
    name: string,
    age: number;
}