export interface Client {
    name: string;
    age: number;
}