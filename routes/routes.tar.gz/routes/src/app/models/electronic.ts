export interface Electronic {
    name: string;
    brand: string;
    price: number;
    description: string;
}
