export interface Book {
    title: string;
    pages: number;
    authors: string[];
}
