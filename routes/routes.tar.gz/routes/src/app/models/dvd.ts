export interface Dvd {
    title: string;
    year: number;
    genre: string;
}
