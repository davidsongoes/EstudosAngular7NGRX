export interface DataModel {
    timestamp: number;
    data: number;
}